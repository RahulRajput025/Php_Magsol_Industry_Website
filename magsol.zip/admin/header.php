 <nav class="header-navbar navbar-expand-lg navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-dark navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav flex-row">
            <li class="nav-item mobile-menu d-lg-none mr-auto">
              <a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
            <li class="nav-item mr-auto"><a class="navbar-brand" href="home.php"><img class="brand-logo" alt="modern admin logo" src="../img/logo.png" style="width: 200px;">

            <li class="nav-item d-none d-lg-block nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i class="toggle-icon ft-toggle-right font-medium-3 white" data-ticon="ft-toggle-right"></i></a></li>

            <li class="nav-item d-lg-none"><a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile"><i class="la la-ellipsis-v"></i></a></li>
          </ul>
        </div>
        <div class="navbar-container content">
          <div class="collapse navbar-collapse" id="navbar-mobile">
            <ul class="nav navbar-nav mr-auto float-left">

              <li class="nav-item d-none d-lg-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>

              <li class="dropdown nav-item mega-dropdown d-none d-lg-block"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">Mega</a>               
              </li>
              
            </ul>
            <ul class="nav navbar-nav float-right">
              
              <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown"><span class="mr-1 user-name text-bold-700">Admin</span><span class="avatar avatar-online"><img src="../img/ajit.jpeg" alt="avatar"><i></i></span></a>
                <div class="dropdown-menu dropdown-menu-right">
                    <?php
                      error_reporting(0);
                      include('dbconfig.php'); 
                      
                       $sql_admin = "SELECT * FROM users ORDER BY id  DESC";
                       $result_admin = mysqli_query($link,$sql_admin);
                       
                     while($row_admin = mysqli_fetch_array($result_admin,MYSQLI_ASSOC))  
                              {
                      ?>

                  <a class="dropdown-item" href="change-password.php?edit=<?php echo $row_admin["id"];?>"><i class="ft-check-square"></i>Change Password</a>
<?php } ?>
                  <div class="dropdown-divider"></div><a class="dropdown-item" href="logout.php"><i class="ft-power"></i> Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <!-- END: Header-->
    <!-- BEGIN: Main Menu-->

    <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="main-menu-content" style="margin-top:100px;">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
          <li class=" nav-item"><a href="home.php"><i class="fa fa-home"></i><span class="menu-title" data-i18n="Dashboard">Dashboard</span></a>
           
          </li>
          
           <li class=" nav-item"><a href="#"><i class="fa fa-table"></i><span class="menu-title" data-i18n="Bootstrap Tables">Products</span></a>
            <ul class="menu-content">
              <li><a class="menu-item" href="add-blog.php"><span data-i18n="Basic Tables">Add Product</span></a>
              </li>
              <li><a class="menu-item" href="blog-list.php"><span data-i18n="Basic Tables">Product List</span></a> </li>
            </ul>
          </li>         
          <li class=" nav-item"><a href="#"><i class="fa fa-table"></i><span class="menu-title" data-i18n="Bootstrap Tables">Manage Pages</span></a>
            <ul class="menu-content">
              <li><a class="menu-item" href="about-list.php"><i></i><span data-i18n="Basic Tables">About Us</span></a>
              </li>
              <li><a class="menu-item" href="add-image.php"><i></i><span data-i18n="Basic Tables">Add Gallery</span></a>
               
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-table"></i><span class="menu-title" data-i18n="Bootstrap Tables">Slider</span></a>
            <ul class="menu-content">
              <li><a class="menu-item" href="add-slider.php"><i></i><span data-i18n="Basic Tables">Add Slider</span></a>
              </li> 
               <li><a class="menu-item" href="slider-list.php"><i></i><span data-i18n="Basic Tables">Slider List</span></a>
              </li>  
            </ul>
          </li>
 
        
       
 <li class=" nav-item"><a href="#"><i class="fa fa-user"></i><span class="menu-title" data-i18n="Bootstrap Tables">Manage</span></a>
            <ul class="menu-content">
          <?php
                    error_reporting(0);
                    include('dbconfig.php');
                                
                    $sql_other = "SELECT * from tbl_details ORDER BY details_id  DESC";
                    $data_other = mysqli_query($link,$sql_other);
                    while($row_other = mysqli_fetch_array($data_other,MYSQLI_ASSOC))  
                              {  
                                ?>
              <li><a class="menu-item" href="edit-details.php?edit=<?php echo $row_other["details_id"];?>"><i></i><span data-i18n="Basic Tables">Manage</span></a></li>
              <?php } ?>
              

             
</ul>
</li>



        
        </ul>
      </div>
    </div>
