<?php
include('dbconfig.php');
/*include('session.php');
*/
$tbl_category_id = $_REQUEST['tbl_category_id'];
$query = "DELETE FROM tbl_category WHERE tbl_category_id = '$tbl_category_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: cotegory-list.php"); 
?>