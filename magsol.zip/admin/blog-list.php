<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="PIXINVENT">
    <title>Magsol | Product List</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/tables/datatable/datatables.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- END: Custom CSS-->

  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
    <?php include'header.php'; ?>
    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->


    <!-- END: Main Menu-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Product</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="#">Product List</a>
                  </li>
                 
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
              <a class="btn btn-info  mb-1" type="button" href="add-blog.php">ADD PRODUCT
              </a>
             
            </div>
          </div>
        </div>
        <div class="content-body">

          <!-- File export table -->
          <section id="file-export">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4 class="card-title">File export</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="card-content collapse show">
                    <div class="card-body card-dashboard dataTables_wrapper dt-bootstrap">
                      
                      <table class="table table-striped table-bordered file-export">
                        <thead>
                          <tr>
                            <th>SR. NO</th>
                            <th>PRODUCT NAME</th>                            
                            <th>STATUS</th>
                            <th>ACTION</th>                 
                          </tr>
                        </thead>
                        <tbody>
                           <?php
                            error_reporting(0);
                            include('dbconfig.php');
                                
                            $sql = "SELECT * from tbl_blog ORDER BY fld_blog_id DESC";
                            $data = mysqli_query($link,$sql);
                            $x=0;
                             while($row = mysqli_fetch_array($data,MYSQLI_ASSOC))  
                              {  
                                $x++;
                          
                               
                          ?>
                          <tr>
                            <td><?php echo $x; ?></td>
                              <td><?php echo $row['fld_blog_name']; ?></td>
                            <td><?php if($row['fld_status'] == '0'){ ?>
                                                  PUBLIC
                                                  <?php } elseif($row['fld_status'] == '1'){?>
                                                  HIDE
                                                  <?php } elseif($row['fld_status'] == '2'){?>
                                                  POPULAR
                                                  <?php } else{
                                                  echo "Not Selected";
                                                }
                                                ?>                                                  
                                                </td>
                            <td><a  href="edit-blog.php?edit=<?php echo $row["fld_blog_id"];?>" title="Edit" class="btn btn-social-icon mr-1 mb-1 btn-bitbucket">
                              <i class="fa fa-edit"></i></a>                        
                            <a class="btn btn-social-icon mr-1 mb-1 btn-flickr" href="delete-blog.php?fld_blog_id=<?php echo $row["fld_blog_id"]; ?>" title="Delete" >   
                              <i class="fa fa-remove"></i></a>                             
                            </td>                 
                          </tr> 
                          <?php } ?>             
                        </tbody>
                        <tfoot>
                          <tr>
                            <th>SR. NO</th>
                            <th>PRODUCT NAME</th>                            
                            <th>STATUS</th>
                            <th>ACTION</th> 
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <!-- File export table -->

        </div>
      </div>
    </div>
    <!-- END: Content-->
    <?php include'footer.php'; ?>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
    <script src="app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.flash.min.js"></script>
    <script src="app-assets/vendors/js/tables/jszip.min.js"></script>
    <script src="app-assets/vendors/js/tables/pdfmake.min.js"></script>
    <script src="app-assets/vendors/js/tables/vfs_fonts.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.html5.min.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.print.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/tables/datatables/datatable-advanced.min.js"></script>
    <!-- END: Page JS-->

  </body>
  <!-- END: Body-->

</html>