<?php
error_reporting(0);
include('dbconfig.php'); 
if(isset($_GET['edit']) )
{
 $seo_id = $_GET['edit'];
 $sql_Category = "SELECT * FROM tbl_seo where  seo_id = '$seo_id'";
 $result_category = mysqli_query($link,$sql_Category);
$row_category = mysqli_fetch_array($result_category);
 
}
 if(isset($_POST['submit']))
{
   
    $home_title = $_POST['home_title'];
     $home_desc = $_POST['home_desc'];
      $home_keywords = $_POST['home_keywords'];
       $about_title = $_POST['about_title'];
        $about_desc = $_POST['about_desc'];
         $about_keywords = $_POST['about_keywords'];
          $service_title = $_POST['service_title'];
           $service_desc = $_POST['service_desc'];
            $service_keywords = $_POST['service_keywords'];
             $portfolio_title = $_POST['portfolio_title'];
              $portfolio_desc = $_POST['portfolio_desc'];
               $portfolio_keywords = $_POST['portfolio_keywords'];
                $blog_title = $_POST['blog_title'];
                 $blog_desc = $_POST['blog_desc'];
                  $blog_keywords = $_POST['blog_keywords'];
                   $contact_title = $_POST['contact_title'];
                    $contact_desc = $_POST['contact_desc'];
                     $contact_keywords = $_POST['contact_keywords'];
                     
    
   
    $sql = " UPDATE tbl_seo SET home_title = '$home_title',home_desc = '$home_desc',home_keywords = '$home_keywords',about_title = '$about_title',about_desc = '$about_desc',about_keywords = '$about_keywords',service_title = '$service_title',service_desc = '$service_desc', service_keywords = '$service_keywords',portfolio_title = '$portfolio_title',portfolio_desc = '$portfolio_desc', portfolio_keywords = '$portfolio_keywords',blog_title = '$blog_title', blog_desc = '$blog_desc',blog_keywords = '$blog_keywords', contact_title = '$contact_title', contact_desc = '$contact_desc', contact_keywords = '$contact_keywords'  WHERE seo_id = '$seo_id'";

       $data = mysqli_query($link,$sql) or die("could not work".mysql_error());

       if($data){      

          header('Location:home.php');
        }
        else{
         $err='<div class="alert alert-danger">

          <strong>Error!</strong>  Not Edit.

        </div>';
     }
}
?>

<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="PIXINVENT">
    <title>Cheesy Musings  | Edit SEO</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/spinner/jquery.bootstrap-touchspin.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/icheck/icheck.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/toggle/bootstrap-switch.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/toggle/switchery.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/validation/form-validation.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/switch.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- END: Custom CSS-->

  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
    <?php include'header.php'; ?>
    <!-- END: Header-->


    <!-- END: Main Menu-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">SEO Details</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="#">SEO Details</a>
                  </li>
                 
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Input Validation start -->
          <section class="input-validation">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="card-content collapse show">
                    <div class="card-body">
                      <?php if($suc !=''){ echo $suc; }elseif($err != ''){ echo $err; }else{} ?>
                      <form class="form-horizontal" action="" method="post" novalidate>
                        <div class="row">
                          <div class="col-lg-12 col-md-12">
                            <div class="form-group">
                              <h5>Home Title</h5>
                              <div class="controls">
                                 <input type="hidden" name="seo_id" value="<?php echo $row_category['seo_id']; ?>" >
                                 <input type="text" name="home_title" class="form-control" value="<?php echo $row_category['home_title']; ?>" >
                              </div>
                            </div>
                            <div class="form-group">
                              <h5>Home Description<span class="required">*</span></h5>
                              <div class="controls">
                                <input type="text" name="home_desc" value="<?php echo $row_category['home_desc']; ?>" class="form-control mb-1" required data-validation-required-message="This field is required">
                               </div>
                              </div>
                            <div class="form-group">
                              <h5>Home Keywords</h5>
                              <div class="controls">
                                <input type="text" name="home_keywords" value="<?php echo $row_category['home_keywords']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>About Title</h5>
                              <div class="controls">
                                <input type="text" name="about_title" value="<?php echo $row_category['about_title']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>About description</h5>
                              <div class="controls">
                                <input type="text" name="about_desc" value="<?php echo $row_category['about_desc']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>About Keywords</h5>
                              <div class="controls">
                                <input type="text" name="about_keywords" value="<?php echo $row_category['about_keywords']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            
                            <div class="form-group">
                              <h5>Blog Category Title</h5>
                              <div class="controls">
                                <input type="text" name="blog_title" value="<?php echo $row_category['blog_title']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>Blog Category description</h5>
                              <div class="controls">
                                <input type="text" name="blog_desc" value="<?php echo $row_category['blog_desc']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>Blog Category Keywords</h5>
                              <div class="controls">
                                <input type="text" name="blog_keywords" value="<?php echo $row_category['blog_keywords']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>Contact title</h5>
                              <div class="controls">
                                <input type="text" name="contact_title" value="<?php echo $row_category['contact_title']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>Contact desciption</h5>
                              <div class="controls">
                                <input type="text" name="contact_desc" value="<?php echo $row_category['contact_desc']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                            <div class="form-group">
                              <h5>Contact Keywords</h5>
                              <div class="controls">
                                <input type="text" name="contact_keywords" value="<?php echo $row_category['contact_keywords']; ?>" class="form-control mb-1">
                               </div>
                            </div>
                         
                             
                            </div>
                          
                          
                          </div>
                          <div class="col-lg-12 col-md-12">
                            <div class="text-right">
                              <button type="submit" class="btn btn-success" name="submit">Submit </button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
<!-- Input Validation end -->


        </div>
      </div>
    </div>
    <!-- END: Content-->

    <?php include'footer.php'; ?>
    <!-- END: Footer-->
    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js"></script>
    <script src="app-assets/vendors/js/forms/validation/jqBootstrapValidation.js"></script>
    <script src="app-assets/vendors/js/forms/icheck/icheck.min.js"></script>
    <script src="app-assets/vendors/js/forms/toggle/bootstrap-switch.min.js"></script>
    <script src="app-assets/vendors/js/forms/toggle/switchery.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/validation/form-validation.js"></script>
    <!-- END: Page JS-->

  </body>
  <!-- END: Body-->

</html>