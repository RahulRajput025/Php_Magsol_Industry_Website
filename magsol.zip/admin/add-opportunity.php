<?php
error_reporting(0);
include('dbconfig.php');
//include('session.php');
//$session_id = $_SESSION['admin_id'];
if(isset($_POST["submit"]))
{
    $fld_opp_name = $_POST['fld_opp_name'];
    $fld_category = $_POST['fld_category'];
    $fld_status = $_POST['fld_status'];


    $filename = $_FILES["fld_file"]["name"];
    $tempname = $_FILES["fld_file"]["tmp_name"];
    $folder = "image/pdf/".$filename;
    move_uploaded_file($tempname,$folder);
       
    $sql = "INSERT INTO tbl_opp (fld_opp_name,fld_category,fld_status,fld_file) VALUES ('$fld_opp_name','$fld_category','0','$folder')";
  
  //echo $sql; die;
  if(mysqli_query($link,$sql)){
           $suc='<div class="alert alert-success">

          <strong>Success!</strong> '.$fld_category.' Added Successfully.

        </div>';

            }else{

               $err='<div class="alert alert-danger">

          <strong>Error!</strong> '.$fld_category.' Not Added.

        </div>';

         }
}

?>

<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Modern admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities with bitcoin dashboard.">
    <meta name="keywords" content="admin template, modern admin template, dashboard template, flat admin template, responsive admin template, web app, crypto dashboard, bitcoin dashboard">
    <meta name="author" content="PIXINVENT">
    <title>Winner India | Add Opportunity</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/selects/select2.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/validation/form-validation.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/switch.min.css">
     <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/file-uploaders/dropzone.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/pages/dropzone.min.css">
    <!-- END: Page CSS-->
  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
  <?php include'header.php'; ?>
    <!-- END: Header-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Opportunity</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="#">Add Opportunity </a>
                  </li>
                 
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
             <a class="btn btn-info  mb-1" type="button" href="opportunity-list.php">OPPORTUNITY LIST</a>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic Select2 start -->
          <section class="basic-select2">
            <div class="row">
              <div class="col-xl-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                       <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                   <?php if($suc !=''){ echo $suc; }elseif($err != ''){ echo $err; }else{} ?>
                  <form class="form-horizontal" action="" method="post" enctype="multipart/form-data" novalidate>
                      <div class="card-content collapse show">
                        <div class="card-body">
                          <div class="form-group">
                            <div class="text-bold-600 font-medium-2">
                             Marketing Plan / Profile / Product Book
                            </div>
                            <select class="select2 form-control" name="fld_category">
                              <optgroup label="Category Name">
                                <option value="Marketing Plan">Marketing Plan</option>
                                <option value="Profile / Product Book">Profile / Product Book</option>
                              </optgroup>
                             
                            </select>
                          </div>
                          <div class="form-group">
                            <div class="text-bold-600 font-medium-2">
                             Name
                            </div>
                           <input type="text" class="form-control" name="fld_opp_name">
                          </div>

                           <div class="form-group">
                            <h5>PDF <span class="required">*</span></h5>
                            <div class="controls">
                              <input type="file" name="fld_file" class="form-control mb-1" >
                            </div>
                          </div>   
                          <div class="form-group">
                            <div class="text-right">
                              <button type="submit" class="btn btn-success" name="submit">Submit </button>
                            </div>
                          </div>                 
                         
                        </div>
                      </div>
                </form>
                </div>
              </div>
             
            </div>
          </section>
          <!-- Basic Select2 end -->



        </div>
      </div>
    </div>
    <!-- END: Content-->

    <?php include'footer.php'; ?>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/select/form-select2.min.js"></script>
    <!-- END: Page JS-->
     <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/validation/form-validation.js"></script>
    <!-- END: Page JS-->
      <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/extensions/dropzone.min.js"></script>
    <!-- END: Page JS-->
  </body>
  <!-- END: Body-->
</html>