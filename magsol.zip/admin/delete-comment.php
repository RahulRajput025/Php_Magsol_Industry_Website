<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_comment_id = $_REQUEST['fld_comment_id'];
$query = "DELETE FROM  tbl_comment WHERE fld_comment_id = '$fld_comment_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: comment.php"); 
?>