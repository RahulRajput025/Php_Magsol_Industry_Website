<?php
error_reporting(0);
include('dbconfig.php');
//include('session.php');
//$session_id = $_SESSION['admin_id'];
if(isset($_POST["submit"]))
{
    $fld_service_name = $_POST['fld_service_name'];
    $fld_short_desc = $_POST['fld_short_desc'];
    $fld_long_desc  = $_POST['fld_long_desc'];
    $fld_status = $_POST['fld_status'];


    $filename = $_FILES["fld_service_photo"]["name"];
    $tempname = $_FILES["fld_service_photo"]["tmp_name"];
    $folder = "image/service/".$filename;
    move_uploaded_file($tempname,$folder);
       
    $sql = "INSERT INTO tbl_service (fld_service_name,fld_short_desc,fld_long_desc ,fld_service_photo,fld_status) VALUES ('$fld_service_name','$fld_short_desc','$fld_long_desc','$folder','$fld_status')";
  
  //echo $sql; die;
  if(mysqli_query($link,$sql)){
           $suc='<div class="alert alert-success">

          <strong>Success!</strong> '.$fld_blog_name.' Added Successfully.

        </div>';
header('Location:service-list.php');
            }else{

               $err='<div class="alert alert-danger">

          <strong>Error!</strong> '.$fld_blog_name.' Not Added.

        </div>';

         }
}

?>
<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
  
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Modern admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities with bitcoin dashboard.">
    <meta name="keywords" content="admin template, modern admin template, dashboard template, flat admin template, responsive admin template, web app, crypto dashboard, bitcoin dashboard">
    <meta name="author" content="PIXINVENT">
    <title>Digital Karona | Add Service</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/editors/summernote.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/editors/codemirror.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/editors/theme/monokai.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- END: Custom CSS-->
    <!-- include summernote css/js -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

   
    <!-- BEGIN: Header-->
    <?php include'header.php'; ?>
    <!-- END: Header-->


    <!-- END: Main Menu-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Add Service</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item active">About
                  </li>
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
             
                <button id="edit" class="" type="hide" > </button>
                <button id="save" class="" type="hide"></button>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic Select2 start -->
         <section id="basic">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-h font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="card-content collapse show">
                    <div class="card-body">
                      <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                          <div class="form-group">
                            <h5>Service Name <span class="required">*</span></h5>
                              <div class="controls">
                                <input type="text" name="fld_service_name" class="form-control mb-1" required data-validation-required-message="This field is required" onkeyup="this.value = this.value.toUpperCase();" required>
                              </div>
                            </div>   
                           

                            <div class="form-group">
                              <h5>Short Description<span class="required">*</span></h5>
                                <div class="controls">
                                  <textarea name="fld_short_desc" class="form-control"></textarea>
                                </div>
                              </div>    
                          <div class="row">

                            
                            <label>Long Description</label>
                            <div class="col-lg-12 col-md-12">
                              <textarea class="summernote" name="fld_long_desc" >
                            </textarea>
                          </div>
                          </div>
                           <div class="form-group">
                              <h5>Service Photo <span class="required">*</span></h5>
                              <div class="controls">
                                <input type="file" name="fld_service_photo" class="form-control mb-1" >
                              </div>
                            </div>  
                            <div class="form-group">
                            <div class="text-bold-600 font-medium-2">
                              Privacy
                            </div>
                            <select class="select2 form-control" name="fld_status">
                              <optgroup label="Privacy">                                
                                <option value="0">Public</option><!--Public-->
                                <option value="1">Private</option><!--Public-->
                              </optgroup>
                             
                            </select>
                          </div> 

                          <div class="row">
                           <div class="col-lg-12 col-md-12">
                              <div class="text-right" style="margin-top: 20px;">
                                <button type="submit" class="btn btn-success" name="submit">Submit </button>
                              </div>
                            </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
</section>
<!-- Basic Summernote end -->

<!-- Summernote Click to edit end -->

        </div>
      </div>
    </div>
    <!-- END: Content-->


  <?php include'footer.php'; ?>

    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/editors/codemirror/lib/codemirror.js"></script>
    <script src="app-assets/vendors/js/editors//mode/xml/xml.js"></script>
    <script src="app-assets/vendors/js/editors/summernote/summernote.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/editors/editor-summernote.min.js"></script>
    <!-- END: Page JS-->

  </body>
  <!-- END: Body-->

</html>