<?php
error_reporting(0);
include('dbconfig.php'); 
if(isset($_GET['edit']) )
{
 $id = $_GET['edit'];
 $sql_admin = "SELECT * FROM users where id = '$id'";
 $result_admin = mysqli_query($link,$sql_admin);
$row_admin1 = mysqli_fetch_array($result_admin);

 
}
 if(isset($_POST['submit']))
{
    $id = $_POST['id'];
    
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    
     $sql = " UPDATE users SET username = '$username',password = '$password'  WHERE id = '$id'";

       $data = mysqli_query($link,$sql) or die("could not work".mysql_error());

       if($data){      

          header('Location:home.php');
        }
        else{
         $err='<div class="alert alert-danger">

          <strong>Error!</strong>  Not Edit.

        </div>';
     }
}
?>

<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="PIXINVENT">
    <title>Cheesy Musings | Change Password</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/selects/select2.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/validation/form-validation.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/switch.min.css">
    <!-- END: Custom CSS-->

  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
  <?php include'header.php'; ?>
    <!-- END: Header-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Change Password</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="#">Change Password</a>
                  </li>
                 
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic Select2 start -->
          <section class="basic-select2">
            <div class="row">
              <div class="col-xl-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                       <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                   <?php if($suc !=''){ echo $suc; }elseif($err != ''){ echo $err; }else{} ?>
                  <form class="form-horizontal" action="" method="post" novalidate>
                      <div class="card-content collapse show">
                        <div class="card-body">
                          <div class="form-group">
                            <h5>Email <span class="required">*</span></h5>
                            <div class="controls">
                              <input type="text" name="username" class="form-control mb-1"  value="<?php echo $row_admin1['username']; ?>">
                              <input type="hidden" name="id" value="<?php echo $row_admin1['id']; ?>" >
                            </div>
                          </div> 
                          <div class="form-group">
                            <h5>Password<span class="required">*</span></h5>
                            <div class="controls">
                              <input type="password" name="password" class="form-control mb-1" required data-validation-required-message="This field is required" value="<?php echo $row_admin1['password']; ?>">
                            </div>
                          </div>       
                         
                          <div class="form-group">
                            <div class="text-right">
                              <button type="submit" class="btn btn-success" name="submit">Submit </button>
                            </div>
                          </div>                 
                         
                        </div>
                      </div>
                </form>
                </div>
              </div>
             
            </div>
          </section>
          <!-- Basic Select2 end -->



        </div>
      </div>
    </div>
    <!-- END: Content-->

    <?php include'footer.php'; ?>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/select/form-select2.min.js"></script>
    <!-- END: Page JS-->
     <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/validation/form-validation.js"></script>
    <!-- END: Page JS-->
  </body>
  <!-- END: Body-->
</html>