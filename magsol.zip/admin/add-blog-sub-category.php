
<?php
error_reporting(0);
include('dbconfig.php');
//include('session.php');
//$session_id = $_SESSION['admin_id'];s
if(isset($_POST["submit"]))
{
  if(isset($_POST['fld_sub_category_name']))
 {
    $fld_sub_category_name = $_POST['fld_sub_category_name'];
    
    $sql_college = "SELECT * FROM tbl_blog_sub_category WHERE fld_sub_category_name='$fld_sub_category_name'";
    $results_college = mysqli_query($link, $sql_college);
    if (mysqli_num_rows($results_college) > 0) {
      $err='<div class="alert alert-danger">
          <strong>Error!</strong> '.$fld_sub_category_name.'  You already added.
        </div>';
    }
    else
    {
  //print_r($_POST);  
    $fld_category_id = $_POST['fld_category_id'];
    $fld_sub_category_name = $_POST['fld_sub_category_name'];
    
      $time = date("d-m-Y")."-".time() ;
  $targetDir = "images/sub_category/";
  $img = basename($_FILES["fld_sub_category_photo"]["name"]);
  $file_name = $time."-".$img;
  $folder = $targetDir . $file_name;
  move_uploaded_file($_FILES["fld_sub_category_photo"]["tmp_name"], $folder);
  

    $fld_sub_category_status = $_POST['fld_sub_category_status'];

    $fld_desc = $_POST['fld_desc'];
    $fld_keywords = $_POST['fld_keywords'];
    $fld_title = $_POST['fld_title'];
    $fld_chronical_url = $_POST['fld_chronical_url'];
    $fld_alt_tag = $_POST['fld_alt_tag'];
     
     
    $sql = "INSERT INTO tbl_blog_sub_category (fld_category_id,fld_sub_category_name,fld_sub_category_photo,fld_sub_category_status,fld_desc,fld_keywords,fld_title,fld_chronical_url,fld_alt_tag) VALUES ('$fld_category_id','$fld_sub_category_name','$folder','$fld_sub_category_status','$fld_desc','$fld_keywords','$fld_title','$fld_chronical_url','$fld_alt_tag')";
  
  //echo $sql; die;
  if(mysqli_query($link,$sql)){
           $suc='<div class="alert alert-success">

          <strong>Success!</strong> '.$fld_sub_category_name.' Added Successfully.

        </div>';

            }else{

               $err='<div class="alert alert-danger">

          <strong>Error!</strong> '.$fld_sub_category_name.' Not Added.

        </div>';

         }
}
}
}

?>

<!DOCTYPE html>

<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <title>Cheesy Musings | Add Sub Category</title>
    <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i%7CQuicksand:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/forms/selects/select2.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/menu/menu-types/vertical-menu-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/validation/form-validation.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/plugins/forms/switch.min.css">
    <!-- END: Custom CSS-->

  </head>
  <!-- END: Head-->

  <!-- BEGIN: Body-->
  <body class="vertical-layout vertical-menu-modern 2-columns   fixed-navbar" data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

    <!-- BEGIN: Header-->
  <?php include'header.php'; ?>
    <!-- END: Header-->
    <!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2 breadcrumb-new">
            <h3 class="content-header-title mb-0 d-inline-block">Sub Category</h3>
            <div class="row breadcrumbs-top d-inline-block">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="home.php">Home</a>
                  </li>
                  <li class="breadcrumb-item"><a href="#">Add Sub Category </a>
                  </li>
                 
                </ol>
              </div>
            </div>
          </div>
          <div class="content-header-right col-md-6 col-12">
            <div class="btn-group float-md-right">
             <a class="btn btn-info  mb-1" type="button" href="blog-sub-category-list.php">SUB CATEGORY LIST</a>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic Select2 start -->
          <section class="input-validation">
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header">
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                      <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="fa fa-minus"></i></a></li>
                        <li><a data-action="reload"><i class="fa fa-rotate-right"></i></a></li>
                        <li><a data-action="expand"><i class="fa fa-window-maximize"></i></a></li>
                        <li><a data-action="close"><i class="fa fa-window-close"></i></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="card-content collapse show">
                    <div class="card-body">
                   <?php if($suc !=''){ echo $suc; }elseif($err != ''){ echo $err; }else{} ?>
                   <form class="form-horizontal" action="" method="post" enctype="multipart/form-data" novalidate>
                    <div class="row">
                      <div class="col-lg-6 col-md-6">
                        <div class="form-group">
                    <h5>Category <span class="required">*</span></h5>
                   
                    <select class="select2 form-control"  name="fld_category_id" required>
                      <option selected>Please Select</option>
                      <?php
                        error_reporting(0);
                        include('db/config.php');
                                                
                        $sql = "SELECT * from tbl_blog_category ORDER BY fld_category_id DESC";
                        $data = mysqli_query($link,$sql);
                        while($row = mysqli_fetch_array($data,MYSQLI_ASSOC))  
                        {    
                      ?>                      
                      <option value="<?php echo $row['fld_category_id']; ?>"><?php echo $row['fld_category_name']; ?></option>
                      <?php } ?>                     
                    </select>
                  </div>
                        <div class="form-group">
                          <h5>Sub Category Name<span class="required">*</span></h5>
                          <div class="controls">
                            <input type="text" class="form-control mb-1" name="fld_sub_category_name" onkeyup="this.value = this.value.toUpperCase();" required data-validation-required-message="This field is required">
                          </div>
                      </div>
                        <div class="form-group">
                          <h5>Keywords</h5>
                          <div class="controls">
                            <input type="text" name="fld_keywords" class="form-control mb-1">
                          </div>
                        </div>
                        <div class="form-group">
                          <h5>Tag Description</h5>
                          <div class="controls">
                            <input type="text" name="fld_desc" class="form-control mb-1">
                          </div>
                        </div>
                             <div class="form-group">
                          <h5>Canonical URL</h5>
                          <div class="controls">
                            <input type="text" name="fld_chronical_url" class="form-control mb-1">
                          </div>
                        </div>
                   
                      </div>
                      <div class="col-lg-6 col-md-6">
                           <div class="form-group">
                    <h5>Status <span class="required">*</span></h5>
                   
                    <select class="select2 form-control"  name="fld_sub_category_status" required>
                      <option selected>Please Select</option>
                      <option value="0">Public</option>
                      <option value="1">Hide</option>
                      <option value="2">Popular</option>
                     
                    </select>
                  </div>
                  <div class="form-group">
                          <h5>Tag Title</h5>
                          <div class="controls">
                            <input type="text" name="fld_title" class="form-control mb-1">
                          </div>
                        </div>  
                        
                          <div class="form-group">
                          <h5>ALT Image</h5>
                          <div class="controls">
                            <input type="text" name="fld_alt_tag" class="form-control mb-1">
                          </div>
                        </div>
                        <div class="form-group">
                          <h5>Sub Category Photo <span class="required">*</span></h5>
                          <div class="controls">
                            <input type="file" name="fld_sub_category_photo" class="form-control mb-1" required>
                          </div>
                        </div>          
                      
                      </div>
                    
                      <div class="text-right">
                          <button type="submit" class="btn btn-success" name="submit">Submit <i class="fa fa-thumbs-o-up position-right"></i></button>
                          <button type="reset" class="btn btn-danger">Reset <i class="fa fa-refresh position-right"></i></button>
                        </div>
                  </form>
                  
                </div>
              </div>
             
            </div>
          </section>
          <!-- Basic Select2 end -->



        </div>
      </div>
    </div>
    <!-- END: Content-->

    <?php include'footer.php'; ?>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/select/form-select2.min.js"></script>
    <!-- END: Page JS-->
     <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/forms/validation/form-validation.js"></script>
    <!-- END: Page JS-->
  </body>
  <!-- END: Body-->
</html>