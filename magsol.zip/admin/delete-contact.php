<?php
include('dbconfig.php');
/*include('session.php');
*/
$tbl_contact_id = $_REQUEST['tbl_contact_id'];
$query = "DELETE FROM tbl_contact WHERE tbl_contact_id = '$tbl_contact_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: contact-list.php"); 
?>