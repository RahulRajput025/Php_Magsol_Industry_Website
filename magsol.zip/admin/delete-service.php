<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_service_id = $_REQUEST['fld_service_id'];
$query = "DELETE FROM tbl_service WHERE fld_service_id = '$fld_service_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: service-list.php"); 
?>