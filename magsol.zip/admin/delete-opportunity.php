<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_opp_id = $_REQUEST['fld_opp_id'];
$query = "DELETE FROM tbl_opp WHERE fld_opp_id = '$fld_opp_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: opportunity-list.php"); 
?>