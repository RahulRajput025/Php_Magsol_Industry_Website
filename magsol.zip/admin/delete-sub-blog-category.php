<?php
include('dbconfig.php');

	
	$sql = "select * from tbl_blog_sub_category";
	$rs = mysqli_query($link, $sql);
	
	
	if(isset($_GET['fld_sub_category_id']))
	{
	 $querySelect = "select * from tbl_blog_sub_category where fld_sub_category_id = ".$_GET['fld_sub_category_id'];
		$ResultSelectStmt = mysqli_query($link,$querySelect);
		$fetchRecords = mysqli_fetch_assoc($ResultSelectStmt);
		
		$fetchImgTitleName = $fetchRecords['fld_sub_category_photo'];
		
		$createDeletePath = $fetchImgTitleName;
		
		if(unlink($createDeletePath))
		{
			$liveSqlQQ = "delete from tbl_blog_sub_category where fld_sub_category_id = ".$fetchRecords['fld_sub_category_id'];
			$rsDelete = mysqli_query($link, $liveSqlQQ);	
			
			if($rsDelete)
			{
				header('location: blog-sub-category-list.php?success=true');
				exit();
			}
		}
		else
		{
			$displayErrMessage = "Sorry, Unable to delete Image";
		}
		
	}

	
?>