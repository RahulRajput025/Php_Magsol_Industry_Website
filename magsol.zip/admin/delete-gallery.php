<?php
include('dbconfig.php');
/*include('session.php');
*/
$tbl_gallery_id=$_REQUEST['tbl_gallery_id'];
$query = "DELETE FROM tbl_gallery WHERE tbl_gallery_id = '$tbl_gallery_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: gallery-list.php"); 
?>