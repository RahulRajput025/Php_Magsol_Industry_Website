<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_id=$_REQUEST['fld_id'];
$query = "DELETE FROM dl_slider WHERE fld_id = '$fld_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: slider-list.php"); 
?>