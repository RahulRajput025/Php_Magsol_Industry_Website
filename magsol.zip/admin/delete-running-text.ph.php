<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_text_id = $_REQUEST['fld_text_id'];
$query = "DELETE FROM tbl_running WHERE fld_text_id = '$fld_text_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: running-text-list.php"); 
?>