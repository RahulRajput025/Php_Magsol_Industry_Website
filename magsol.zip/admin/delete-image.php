<?php
include('dbconfig.php');
	
	$sql = "SELECT * from tbl_image";
	$rs = mysqli_query($link, $sql);
	
	
	if(isset($_GET['fld_image_id']))
	{
		$querySelect = "SELECT * from tbl_image where fld_image_id = ".$_GET['fld_image_id'];
		$ResultSelectStmt = mysqli_query($link,$querySelect);
		$fetchRecords = mysqli_fetch_assoc($ResultSelectStmt);
		
		$fetchImgTitleName = $fetchRecords['fld_image'];
		
		$createDeletePath = $fetchImgTitleName;
		
		if(unlink($createDeletePath))
		{
			$liveSqlQQ = "DELETE from tbl_image where fld_image_id = ".$fetchRecords['fld_image_id'];
			$rsDelete = mysqli_query($link, $liveSqlQQ);	
			
			if($rsDelete)
			{
				header('location:image-list.php?success=true');
				exit();
			}
		}
		else
		{
			$displayErrMessage = "Sorry, Unable to delete Image";
		}
		
	}

	
?>