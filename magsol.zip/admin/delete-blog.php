<?php
include('dbconfig.php');
/*include('session.php');
*/
$fld_blog_id = $_REQUEST['fld_blog_id'];
$query = "DELETE FROM tbl_blog WHERE fld_blog_id = '$fld_blog_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: blog-list.php"); 
?>