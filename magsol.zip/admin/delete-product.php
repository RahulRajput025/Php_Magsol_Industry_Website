<?php
include('dbconfig.php');
/*include('session.php');
*/
$tbl_product_id=$_REQUEST['tbl_product_id'];
$query = "DELETE FROM tbl_product WHERE tbl_product_id = '$tbl_product_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: product-list.php"); 
?>