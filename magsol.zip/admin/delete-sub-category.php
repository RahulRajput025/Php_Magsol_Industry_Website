<?php
include('dbconfig.php');
/*include('session.php');
*/
$tbl_sub_category_id=$_REQUEST['tbl_sub_category_id'];
$query = "DELETE FROM tbl_sub_category WHERE tbl_sub_category_id = '$tbl_sub_category_id' "; 
$result = mysqli_query($link,$query) or die ( mysqli_error($link));
header("Location: sub-category-list.php"); 
?>